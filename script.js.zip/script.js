let scene, camera, renderer;
        let ball;
        let playersTeam1 = [];
        let playersTeam2 = [];
        let velocitiesTeam1 = [];
        let velocitiesTeam2 = [];
        let keeperTeam1, keeperTeam2;
        let keeperVelocity1 = { x: 0, z: 0 };
        let keeperVelocity2 = { x: 0, z: 0 };

        let scoreP1 = 0, scoreP2 = 0;
        let timer = 60;
        let timerInterval;
        let gameEnded = false;

        const speed = 0.03;
        const maxSpeed = 0.08;
        const keeperSpeed = 0.06;
        const ballSpeed = 0.15;
        const friction = 0.92;
        const fieldWidth = 20;
        const fieldLength = 30;

        let velocityBall = { x: 0, z: 0 };
        const keys = {};

        // AI States
        const AIStates = {
            DEFEND: 'defend',
            ATTACK: 'attack',
            SUPPORT: 'support',
            CHASE_BALL: 'chase_ball',
            PASS: 'pass',
            SHOOT: 'shoot'
        };

        function init() {
            scene = new THREE.Scene();
            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setClearColor(0x87CEEB, 1);
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.shadowMap.enabled = true;
            renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            document.body.appendChild(renderer.domElement);

            camera.position.set(30, 15, 8);
            camera.lookAt(0, 0, 0);

            // Lighting
            const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
            scene.add(ambientLight);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(10, 20, 5);
            directionalLight.castShadow = true;
            directionalLight.shadow.mapSize.width = 2048;
            directionalLight.shadow.mapSize.height = 2048;
            scene.add(directionalLight);

            createField();
            createBall();
            createTeamPlayers();
            createKeepers();
            createGoals();

            document.addEventListener('keydown', onKeyDown);
            document.addEventListener('keyup', onKeyUp);
            window.addEventListener('resize', onWindowResize);

            updateScore();
            startTimer();
            createGameOverScreen();

            animate();
        }

        function createField() {
            // Main field
            const fieldGeometry = new THREE.PlaneGeometry(fieldWidth, fieldLength);
            const fieldMaterial = new THREE.MeshLambertMaterial({ color: 0x228B22 });
            const field = new THREE.Mesh(fieldGeometry, fieldMaterial);
            field.rotation.x = -Math.PI / 2;
            field.receiveShadow = true;
            scene.add(field);

            // Center circle
            const circleGeometry = new THREE.RingGeometry(4.8, 5, 32);
            const circleMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });
            const circle = new THREE.Mesh(circleGeometry, circleMaterial);
            circle.rotation.x = -Math.PI / 2;
            circle.position.y = 0.01;
            scene.add(circle);

            // Center line
            const lineGeometry = new THREE.PlaneGeometry(fieldWidth, 0.2);
            const lineMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });
            const centerLine = new THREE.Mesh(lineGeometry, lineMaterial);
            centerLine.rotation.x = -Math.PI / 2;
            centerLine.position.y = 0.01;
            scene.add(centerLine);

            // Goal areas
            const goalAreaGeometry = new THREE.PlaneGeometry(8, 0.2);
            const goalArea1 = new THREE.Mesh(goalAreaGeometry, lineMaterial);
            goalArea1.rotation.x = -Math.PI / 2;
            goalArea1.position.set(0, 0.01, -fieldLength/2 + 6);
            scene.add(goalArea1);

            const goalArea2 = new THREE.Mesh(goalAreaGeometry, lineMaterial);
            goalArea2.rotation.x = -Math.PI / 2;
            goalArea2.position.set(0, 0.01, fieldLength/2 - 6);
            scene.add(goalArea2);
        }

        function createBall() {
            const ballGeometry = new THREE.SphereGeometry(0.5, 32, 32);
            const ballMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });
            ball = new THREE.Mesh(ballGeometry, ballMaterial);
            ball.position.set(0, 0.5, 0);
            ball.castShadow = true;
            scene.add(ball);
        }

        function createPlayer(color, x, y, z, isKeeper = false) {
            const geometry = new THREE.CylinderGeometry(0.6, 0.6, 1.5, 32);
            const material = new THREE.MeshLambertMaterial({ 
                color: isKeeper ? (color === 0xff0000 ? 0xff8800 : 0x0088ff) : color 
            });
            const player = new THREE.Mesh(geometry, material);
            player.position.set(x, y, z);
            player.castShadow = true;
            return player;
        }

        function createTeamPlayers() {
            // Team 1 field players (3 spelers + 1 keeper)
            const positionsTeam1 = [
                [-2, -8], [-4, -5], [2, -7] // 3 field players
            ];
            const positionsTeam2 = [
                [2, 8], [4, 5], [-2, 7] // 3 field players
            ];

            for (let i = 0; i < 3; i++) {
                const p1 = createPlayer(0xff0000, positionsTeam1[i][0], 0.75, positionsTeam1[i][1]);
                scene.add(p1);
                playersTeam1.push(p1);
                velocitiesTeam1.push({ x: 0, z: 0 });

                const p2 = createPlayer(0x0000ff, positionsTeam2[i][0], 0.75, positionsTeam2[i][1]);
                scene.add(p2);
                playersTeam2.push(p2);
                velocitiesTeam2.push({ x: 0, z: 0 });
            }
        }

        function createKeepers() {
            // Keeper Team 1 (rood/oranje)
            keeperTeam1 = createPlayer(0xff0000, 0, 0.75, -fieldLength/2 + 2, true);
            scene.add(keeperTeam1);

            // Keeper Team 2 (blauw/lichtblauw)
            keeperTeam2 = createPlayer(0x0000ff, 0, 0.75, fieldLength/2 - 2, true);
            scene.add(keeperTeam2);
        }

        function createGoals() {
            const goal1 = createGoal(-fieldLength / 2 + 1);
            const goal2 = createGoal(fieldLength / 2 - 1);
            scene.add(goal1, goal2);
        }

        function createGoal(zPosition) {
            const goalWidth = 6;
            const goalHeight = 3;
            const goalDepth = 2;

            const goalMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });

            const postGeometry = new THREE.CylinderGeometry(0.1, 0.1, goalHeight, 16);
            const crossbarGeometry = new THREE.CylinderGeometry(0.1, 0.1, goalWidth, 16);

            const leftPost = new THREE.Mesh(postGeometry, goalMaterial);
            const rightPost = new THREE.Mesh(postGeometry, goalMaterial);
            const crossbar = new THREE.Mesh(crossbarGeometry, goalMaterial);

            leftPost.position.set(-goalWidth / 2, goalHeight / 2, zPosition);
            rightPost.position.set(goalWidth / 2, goalHeight / 2, zPosition);
            crossbar.position.set(0, goalHeight, zPosition);
            crossbar.rotation.z = Math.PI / 2;

            const netGeometry = new THREE.PlaneGeometry(goalWidth, goalHeight);
            const netMaterial = new THREE.MeshLambertMaterial({ 
                color: 0xdddddd, 
                transparent: true, 
                opacity: 0.7, 
                side: THREE.DoubleSide 
            });
            const net = new THREE.Mesh(netGeometry, netMaterial);
            net.position.set(0, goalHeight / 2, zPosition + Math.sign(zPosition) * goalDepth / 2);

            const goalGroup = new THREE.Group();
            goalGroup.add(leftPost, rightPost, crossbar, net);

            // Cast shadows
            leftPost.castShadow = true;
            rightPost.castShadow = true;
            crossbar.castShadow = true;

            return goalGroup;
        }

        function distance(obj1, obj2) {
            return Math.sqrt((obj1.position.x - obj2.position.x) ** 2 + (obj1.position.z - obj2.position.z) ** 2);
        }

        function shootBall(player, power = 1) {
            const direction = {
                x: ball.position.x - player.position.x,
                z: ball.position.z - player.position.z
            };
            
            const magnitude = Math.sqrt(direction.x * direction.x + direction.z * direction.z);
            if (magnitude > 0) {
                velocityBall.x = (direction.x / magnitude) * ballSpeed * power;
                velocityBall.z = (direction.z / magnitude) * ballSpeed * power;
            }
        }

        function passBall(player, target) {
            const direction = {
                x: target.position.x - ball.position.x,
                z: target.position.z - ball.position.z
            };
            
            const magnitude = Math.sqrt(direction.x * direction.x + direction.z * direction.z);
            if (magnitude > 0) {
                const passSpeed = Math.min(ballSpeed * 0.8, magnitude * 0.1);
                velocityBall.x = (direction.x / magnitude) * passSpeed;
                velocityBall.z = (direction.z / magnitude) * passSpeed;
            }
        }

        function onKeyDown(e) { keys[e.key] = true; }
        function onKeyUp(e) { keys[e.key] = false; }

        function updateMovement() {
            if (gameEnded) return;

            const acc = 0.02;

            // Player 1 (team 1) controls - WASD
            if (keys['w']) velocitiesTeam1[0].z -= acc;
            if (keys['s']) velocitiesTeam1[0].z += acc;
            if (keys['a']) velocitiesTeam1[0].x -= acc;
            if (keys['d']) velocitiesTeam1[0].x += acc;

            // Player 1 (team 2) controls - Arrow keys
            if (keys['ArrowUp']) velocitiesTeam2[0].z -= acc;
            if (keys['ArrowDown']) velocitiesTeam2[0].z += acc;
            if (keys['ArrowLeft']) velocitiesTeam2[0].x -= acc;
            if (keys['ArrowRight']) velocitiesTeam2[0].x += acc;

            // Shoot ball
            if (keys['Shift'] && distance(playersTeam1[0], ball) < 1.5) shootBall(playersTeam1[0], 1.2);
            if (keys['/'] && distance(playersTeam2[0], ball) < 1.5) shootBall(playersTeam2[0], 1.2);
        }

        function updatePlayerPosition(player, velocity) {
            player.position.x = Math.max(-fieldWidth / 2, Math.min(fieldWidth / 2, player.position.x + velocity.x));
            player.position.z = Math.max(-fieldLength / 2, Math.min(fieldLength / 2, player.position.z + velocity.z));

            velocity.x *= friction;
            velocity.z *= friction;
        }

        function updateKeeperAI() {
            if (gameEnded) return;

            // Keeper Team 1 AI
            const keeper1TargetX = Math.max(-3, Math.min(3, ball.position.x));
            const keeper1TargetZ = -fieldLength/2 + 2;
            
            const dx1 = keeper1TargetX - keeperTeam1.position.x;
            const dz1 = keeper1TargetZ - keeperTeam1.position.z;
            
            keeperVelocity1.x += dx1 * 0.03;
            keeperVelocity1.z += dz1 * 0.03;
            
            keeperVelocity1.x = Math.max(-keeperSpeed, Math.min(keeperSpeed, keeperVelocity1.x));
            keeperVelocity1.z = Math.max(-keeperSpeed, Math.min(keeperSpeed, keeperVelocity1.z));

            // Keeper Team 2 AI
            const keeper2TargetX = Math.max(-3, Math.min(3, ball.position.x));
            const keeper2TargetZ = fieldLength/2 - 2;
            
            const dx2 = keeper2TargetX - keeperTeam2.position.x;
            const dz2 = keeper2TargetZ - keeperTeam2.position.z;
            
            keeperVelocity2.x += dx2 * 0.03;
            keeperVelocity2.z += dz2 * 0.03;
            
            keeperVelocity2.x = Math.max(-keeperSpeed, Math.min(keeperSpeed, keeperVelocity2.x));
            keeperVelocity2.z = Math.max(-keeperSpeed, Math.min(keeperSpeed, keeperVelocity2.z));

            // Update keeper positions
            keeperTeam1.position.x = Math.max(-fieldWidth/2, Math.min(fieldWidth/2, keeperTeam1.position.x + keeperVelocity1.x));
            keeperTeam1.position.z = Math.max(-fieldLength/2, Math.min(-fieldLength/2 + 6, keeperTeam1.position.z + keeperVelocity1.z));
            
            keeperTeam2.position.x = Math.max(-fieldWidth/2, Math.min(fieldWidth/2, keeperTeam2.position.x + keeperVelocity2.x));
            keeperTeam2.position.z = Math.max(fieldLength/2 - 6, Math.min(fieldLength/2, keeperTeam2.position.z + keeperVelocity2.z));

            keeperVelocity1.x *= friction;
            keeperVelocity1.z *= friction;
            keeperVelocity2.x *= friction;
            keeperVelocity2.z *= friction;

            // Keeper ball interaction
           if (distance(keeperTeam1, ball) < 1.2 && ball.position.z < 0) {
    // 50% kans om te passen, anders schieten
    if (Math.random() < 0.5) {
        const passTarget = findBestPassTarget(keeperTeam1, 1);
        if (passTarget) {
            passBall(keeperTeam1, passTarget);
        } else {
            shootBall(keeperTeam1, 1.2);
        }
    } else {
        shootBall(keeperTeam1, 1.2);
    }
}

            
          if (distance(keeperTeam2, ball) < 1.2 && ball.position.z > 0) {
    if (Math.random() < 0.5) {
        const passTarget = findBestPassTarget(keeperTeam2, 2);
        if (passTarget) {
            passBall(keeperTeam2, passTarget);
        } else {
            shootBall(keeperTeam2, 1.2);
        }
    } else {
        shootBall(keeperTeam2, 1.2);
    }
}

        }

        function getAIState(player, team, playerIndex) {
            const ballDist = distance(player, ball);
            const isTeam1 = team === 1;
            const ownGoalZ = isTeam1 ? -fieldLength/2 : fieldLength/2;
            const enemyGoalZ = isTeam1 ? fieldLength/2 : -fieldLength/2;
            
            // Is ball close to own goal?
            const ballNearOwnGoal = isTeam1 ? ball.position.z < -5 : ball.position.z > 5;
            
            // Is ball in attacking third?
            const ballInAttackingThird = isTeam1 ? ball.position.z > 5 : ball.position.z < -5;
            
            if (ballDist < 2 && ballNearOwnGoal) return AIStates.DEFEND;
            if (ballDist < 1.5) return AIStates.CHASE_BALL;
            if (ballInAttackingThird && playerIndex === 2) return AIStates.ATTACK; // Forward
            if (ballNearOwnGoal) return AIStates.DEFEND;
            return AIStates.SUPPORT;
        }

        function findBestPassTarget(player, team) {
            const teammates = team === 1 ? playersTeam1 : playersTeam2;
            let bestTarget = null;
            let bestScore = -1;
            
            teammates.forEach(teammate => {
                if (teammate === player) return;
                
                const dist = distance(player, teammate);
                const towardsGoal = team === 1 ? teammate.position.z > player.position.z : teammate.position.z < player.position.z;
                const score = (towardsGoal ? 2 : 1) / (dist + 1);
                
                if (score > bestScore) {
                    bestScore = score;
                    bestTarget = teammate;
                }
            });
            
            return bestTarget;
        }

        function updateSmartAI() {
            if (gameEnded) return;

            // Team 1 AI (rood)
            for (let i = 1; i < playersTeam1.length; i++) {
                const player = playersTeam1[i];
                const velocity = velocitiesTeam1[i];
                const state = getAIState(player, 1, i);
                const ballDist = distance(player, ball);
                
                let targetX = player.position.x;
                let targetZ = player.position.z;
                
              switch (state) {
    case AIStates.CHASE_BALL:
        targetX = ball.position.x;
        targetZ = ball.position.z;

        if (ballDist < 1.2) {
            const goalZ = fieldLength / 2;
            const closeToGoal = ball.position.z > goalZ - 5;

            if (closeToGoal) {
                shootBall(player, 1.5);
            } else {
                const passTarget = findBestPassTarget(player, 1);
                if (passTarget && Math.random() < 0.6) {
                    passBall(player, passTarget);
                } else {
                    // Dribbel richting goal
                    targetX = 0;
                    targetZ = fieldLength / 2;
                }
            }
        }
        break;

    case AIStates.ATTACK:
        // Vrijlopen in aanval
        const offsetX = (i % 2 === 0 ? -4 : 4);
        const offsetZ = Math.random() * 5 + 5;
        targetX = ball.position.x + offsetX;
        targetZ = ball.position.z + offsetZ;

        // Vraag bal met kleine kans
        if (Math.random() < 0.01) {
            const passer = playersTeam1.find((p, idx) =>
                idx !== i && distance(p, ball) < 1.5
            );
            if (passer) passBall(passer, player);
        }
        break;

    case AIStates.DEFEND:
        // Positie tussen goal en bal
        ta

                }
                
                // Move towards target
                const dx = targetX - player.position.x;
                const dz = targetZ - player.position.z;
                const dist = Math.sqrt(dx * dx + dz * dz);
                
                if (dist > 0.5) {
                    velocity.x += (dx / dist) * 0.015;
                    velocity.z += (dz / dist) * 0.015;
                }
                
                velocity.x = Math.max(-maxSpeed, Math.min(maxSpeed, velocity.x));
                velocity.z = Math.max(-maxSpeed, Math.min(maxSpeed, velocity.z));
            }

            // Team 2 AI (blauw) - Mirror logic
            for (let i = 1; i < playersTeam2.length; i++) {
                const player = playersTeam2[i];
                const velocity = velocitiesTeam2[i];
                const state = getAIState(player, 2, i);
                const ballDist = distance(player, ball);
                
                let targetX = player.position.x;
                let targetZ = player.position.z;
                
       switch(state) {
    case AIStates.CHASE_BALL:
        // Alleen 1 speler mag echt de bal najagen
        if (i === getClosestPlayerToBall(playersTeam2)) {
            targetX = ball.position.x;
            targetZ = ball.position.z;

            if (ballDist < 1.2) {
                // Beslissen tussen schot, pass of dribble
                if (ball.position.z < -10) {
                    shootBall(player, 1.5);
                } else {
                    const passTarget = findBestPassTarget(player, 2);
                    if (passTarget && Math.random() < 0.6) {
                        passBall(player, passTarget);
                    } else {
                        // Dribbel richting goal
                        velocity.x += (0 - player.position.x) * 0.01;
                        velocity.z += (-fieldLength/2 - player.position.z) * 0.01;
                    }
                }
            }
        } else {
            // Anderen gaan naar support
            state = AIStates.SUPPORT;
        }
        break;

    case AIStates.ATTACK:
        // Loopt zich vrij in een scoringspositie
        targetX = (Math.random() - 0.5) * 10;
        targetZ = -fieldLength/2 + 5 + Math.random() * 4;
        break;

    case AIStates.DEFEND:
        // Blijft tussen bal en doel
        targetX = ball.position.x * 0.6;
        targetZ = ball.position.z + 5;
        break;

    case AIStates.SUPPORT:
        // Positioneert zich voor een pass
        const offsetX = (i % 2 === 0 ? -4 : 4);
        const offsetZ = -6 + Math.random() * 3;
        targetX = ball.position.x + offsetX;
        targetZ = ball.position.z + offsetZ;

        // Vraag actief om de bal als in goede positie
        if (distance(player, ball) > 1.5 && Math.random() < 0.02) {
            const passer = playersTeam2[getClosestPlayerToBall(playersTeam2)];
            if (distance(passer, ball) < 1.2) {
                passBall(passer, player);
            }
        }
        break;
}


function getClosestPlayerToBall(players) {
    let closestIndex = 1;
    let minDist = Infinity;
    for (let j = 1; j < players.length; j++) {
        const dist = distance(players[j], ball);
        if (dist < minDist) {
            minDist = dist;
            closestIndex = j;
        }
    }
    return closestIndex;
}

                // Move towards target
                const dx = targetX - player.position.x;
                const dz = targetZ - player.position.z;
                const dist = Math.sqrt(dx * dx + dz * dz);
                
                if (dist > 0.5) {
                    velocity.x += (dx / dist) * 0.015;
                    velocity.z += (dz / dist) * 0.015;
                }
                
                velocity.x = Math.max(-maxSpeed, Math.min(maxSpeed, velocity.x));
                velocity.z = Math.max(-maxSpeed, Math.min(maxSpeed, velocity.z));
            }
        }

        function updateBall() {
            ball.position.x += velocityBall.x;
            ball.position.z += velocityBall.z;

            velocityBall.x *= friction;
            velocityBall.z *= friction;

            // Ball collision with field boundaries
            if (ball.position.x > fieldWidth / 2) {
                ball.position.x = fieldWidth / 2;
                velocityBall.x *= -0.7;
            }
            if (ball.position.x < -fieldWidth / 2) {
                ball.position.x = -fieldWidth / 2;
                velocityBall.x *= -0.7;
            }
            if (ball.position.z > fieldLength / 2) {
                ball.position.z = fieldLength / 2;
                velocityBall.z *= -0.7;
            }
            if (ball.position.z < -fieldLength / 2) {
                ball.position.z = -fieldLength / 2;
                velocityBall.z *= -0.7;
            }

            // Ball collision with players
            [...playersTeam1, ...playersTeam2].forEach(player => {
                if (distance(player, ball) < 1.0) {
                    const dx = ball.position.x - player.position.x;
                    const dz = ball.position.z - player.position.z;
                    const dist = Math.sqrt(dx * dx + dz * dz);
                    if (dist > 0) {
                        velocityBall.x += (dx / dist) * 0.05;
                        velocityBall.z += (dz / dist) * 0.05;
                    }
                }
            });
        }

        function checkGoal() {
            if (ball.position.z < -fieldLength / 2 + 1 && Math.abs(ball.position.x) < 3) {
                scoreP2++;
                updateScore();
                resetPositions('P2');
            } else if (ball.position.z > fieldLength / 2 - 1 && Math.abs(ball.position.x) < 3) {
                scoreP1++;
                updateScore();
                resetPositions('P1');
            }
        }

        function updateScore() {
            const scoreBoard = document.getElementById("scoreboard");
            if (scoreBoard) scoreBoard.innerText = `Rood: ${scoreP1} - Blauw: ${scoreP2}`;
        }

        function updateTimer() {
            const timerElement = document.getElementById("timer");
            if (timer > 0) {
                timer--;
                if (timerElement) timerElement.innerText = `Tijd: ${timer}`;
            } else {
                clearInterval(timerInterval);
                gameEnded = true;
                showGameOverScreen();
            }
        }

        function startTimer() {
            timerInterval = setInterval(updateTimer, 1000);
        }

        function resetPositions(scoringTeam) {
            ball.position.set(0, 0.5, 0);
            velocityBall.x = 0;
            velocityBall.z = 0;

            // Reset field players to start positions
            const positionsTeam1 = [
                [-2, -8], [-4, -5], [2, -7]
            ];
            const positionsTeam2 = [
                [2, 8], [4, 5], [-2, 7]
            ];

            playersTeam1.forEach((p, i) => {
                p.position.set(positionsTeam1[i][0], 0.75, positionsTeam1[i][1]);
                velocitiesTeam1[i].x = 0;
                velocitiesTeam1[i].z = 0;
            });

            playersTeam2.forEach((p, i) => {
                p.position.set(positionsTeam2[i][0], 0.75, positionsTeam2[i][1]);
                velocitiesTeam2[i].x = 0;
                velocitiesTeam2[i].z = 0;
            });

            // Reset keepers
            keeperTeam1.position.set(0, 0.75, -fieldLength/2 + 2);
            keeperTeam2.position.set(0, 0.75, fieldLength/2 - 2);
            keeperVelocity1.x = 0;
            keeperVelocity1.z = 0;
            keeperVelocity2.x = 0;
            keeperVelocity2.z = 0;

            // Position ball slightly towards non-scoring team
            if (scoringTeam === 'P1') ball.position.z = 3;
            else ball.position.z = -3;
        }

        function createGameOverScreen() {
            const gameOverScreen = document.createElement('div');
            gameOverScreen.id = 'gameOverScreen';

            const gameOverContent = document.createElement('div');
            gameOverContent.id = 'gameOverContent';

            const title = document.createElement('h1');
            title.id = 'gameOverTitle';
            title.textContent = 'WEDSTRIJD AFGELOPEN!';

            const finalScore = document.createElement('div');
            finalScore.id = 'finalScore';

            const winnerAnnouncement = document.createElement('div');
            winnerAnnouncement.id = 'winnerAnnouncement';

            const restartButton = document.createElement('button');
            restartButton.id = 'restartButton';
            restartButton.textContent = 'NIEUWE WEDSTRIJD';
            restartButton.onclick = restartGame;

            gameOverContent.appendChild(title);
            gameOverContent.appendChild(finalScore);
            gameOverContent.appendChild(winnerAnnouncement);
            gameOverContent.appendChild(restartButton);
            gameOverScreen.appendChild(gameOverContent);

            document.body.appendChild(gameOverScreen);
        }

        function showGameOverScreen() {
            const screen = document.getElementById('gameOverScreen');
            const finalScore = document.getElementById('finalScore');
            const winner = document.getElementById('winnerAnnouncement');

            finalScore.textContent = `Eindstand: Rood ${scoreP1} - ${scoreP2} Blauw`;

            if (scoreP1 > scoreP2) {
                winner.textContent = '🏆 ROOD WINT! 🏆';
                winner.className = 'winner-red';
                createConfetti();
            } else if (scoreP2 > scoreP1) {
                winner.textContent = '🏆 BLAUW WINT! 🏆';
                winner.className = 'winner-blue';
                createConfetti();
            } else {
                winner.textContent = '🤝 GELIJKSPEL! 🤝';
                winner.className = 'tie-game';
            }

            screen.style.display = 'flex';
        }

        function createConfetti() {
            for (let i = 0; i < 50; i++) {
                setTimeout(() => {
                    const confetti = document.createElement('div');
                    confetti.className = 'confetti';
                    confetti.style.left = Math.random() * 100 + '%';
                    confetti.style.animationDelay = Math.random() * 2 + 's';
                    confetti.style.background = `hsl(${Math.random() * 360}, 70%, 50%)`;
                    document.getElementById('gameOverScreen').appendChild(confetti);

                    setTimeout(() => confetti.remove(), 3000);
                }, i * 50);
            }
        }

        function restartGame() {
            scoreP1 = 0;
            scoreP2 = 0;
            timer = 60;
            gameEnded = false;
            document.getElementById('gameOverScreen').style.display = 'none';
            resetPositions('P1');
            updateScore();
            document.getElementById("timer").innerText = `Tijd: ${timer}`;
            clearInterval(timerInterval);
            startTimer();
        }

        function animate() {
            requestAnimationFrame(animate);

            updateMovement();
            updateSmartAI();
            updateKeeperAI();

            playersTeam1.forEach((player, i) => {
                updatePlayerPosition(player, velocitiesTeam1[i]);
            });
            playersTeam2.forEach((player, i) => {
                updatePlayerPosition(player, velocitiesTeam2[i]);
            });

            updateBall();
            checkGoal();

            renderer.render(scene, camera);
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }

        init();