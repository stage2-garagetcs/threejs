// Game state
let gameState = 'start'; // 'start', 'coinflip', 'playing'
let selectedTeam = null;
let playerTeam = null;
let kickoffTeam = null;

// Constanten
const FIELD_W = 120;
const FIELD_L = 80;
const GOAL_W = 22;
const GOAL_H = 10;
const GOAL_D = 10;
const PLAYER_SIZE = 5;
const BALL_SIZE = 1.8;

// Vertalingen
const translations = {
    nl: {
        team1: "Rood Team",
        team2: "Blauw Team",
        score: "Score",
        time: "Tijd",
        gameOver: "Spel Afgelopen!",
        finalScore: "Eindstand",
        newGame: "Nieuw Spel",
        heads: "Kop",
        tails: "Munt",
        coinResultWin: "Het is {result}! Je hebt gewonnen en krijgt de aftrap!",
        coinResultLose: "Het is {result}! Je hebt verloren, de tegenstander krijgt de aftrap.",
        chooseTeam: "Kies je team:",
        startGame: "Start Spel"
    },
    en: {
        team1: "Red Team",
        team2: "Blue Team",
        score: "Score",
        time: "Time",
        gameOver: "Game Over!",
        finalScore: "Final Score",
        newGame: "New Game",
        heads: "Heads",
        tails: "Tails",
        coinResultWin: "It's {result}! You won and get the kickoff!",
        coinResultLose: "It's {result}! You lost, opponent gets the kickoff.",
        chooseTeam: "Choose your team:",
        startGame: "Start Game"
    },
    es: {
        team1: "Equipo Rojo",
        team2: "Equipo Azul",
        score: "Puntuación",
        time: "Tiempo",
        gameOver: "¡Juego Terminado!",
        finalScore: "Puntuación Final",
        newGame: "Nuevo Juego",
        heads: "Cara",
        tails: "Cruz",
        coinResultWin: "¡Es {result}! ¡Ganaste y sacas de centro!",
        coinResultLose: "¡Es {result}! Perdiste, el oponente saca de centro.",
        chooseTeam: "Elige tu equipo:",
        startGame: "Iniciar Juego"
    },
    fr: {
        team1: "Équipe Rouge",
        team2: "Équipe Bleue",
        score: "Score",
        time: "Temps",
        gameOver: "Jeu Terminé!",
        finalScore: "Score Final",
        newGame: "Nouveau Jeu",
        heads: "Face",
        tails: "Pile",
        coinResultWin: "C'est {result}! Vous avez gagné et faites l'engagement!",
        coinResultLose: "C'est {result}! Vous avez perdu, l'adversaire fait l'engagement.",
        chooseTeam: "Choisissez votre équipe:",
        startGame: "Commencer le Jeu"
    }
};

let currentLanguage = 'nl';

function changeLanguage(lang) {
    currentLanguage = lang;
    updateTexts();
    
    // Update active language button
    document.querySelectorAll('.lang-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

function updateTexts() {
    const t = translations[currentLanguage];
    
    // Update game UI if visible
    if (gameState === 'playing') {
        const elements = {
            'team1-name': t.team1,
            'team2-name': t.team2,
            'time-label': t.time
        };
        
        Object.keys(elements).forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = elements[id];
            }
        });
    }
}

// Menu event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Team selection
    document.getElementById('team-red').addEventListener('click', function() {
        selectTeam('red');
    });
    
    document.getElementById('team-blue').addEventListener('click', function() {
        selectTeam('blue');
    });
    
    // Start game button
    document.getElementById('start-game').addEventListener('click', function() {
        if (selectedTeam) {
            showCoinFlip();
        }
    });
    
    // Coin flip buttons
    document.getElementById('heads-btn').addEventListener('click', function() {
        flipCoin('heads');
    });
    
    document.getElementById('tails-btn').addEventListener('click', function() {
        flipCoin('tails');
    });
    
    // Continue to game
    document.getElementById('continue-game').addEventListener('click', function() {
        startGame();
    });
});

function selectTeam(team) {
    selectedTeam = team;
    playerTeam = team === 'red' ? 1 : 2;
    
    // Update button styles
    document.querySelectorAll('.team-btn').forEach(btn => btn.classList.remove('selected'));
    document.getElementById(`team-${team}`).classList.add('selected');
    
    // Enable start button
    document.getElementById('start-game').disabled = false;
}

function showCoinFlip() {
    document.getElementById('start-screen').classList.add('hidden');
    document.getElementById('coin-flip-screen').classList.remove('hidden');
    gameState = 'coinflip';
}

function flipCoin(choice) {
    const coin = document.getElementById('coin');
    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    
    // Animate coin
    coin.classList.add('flipping');
    
    // Disable buttons during flip
    document.querySelectorAll('.coin-btn').forEach(btn => btn.disabled = true);
    
    setTimeout(() => {
        coin.classList.remove('flipping');
        
        // Show result
        const t = translations[currentLanguage];
        const resultText = result === 'heads' ? t.heads : t.tails;
        const won = choice === result;
        
        if (won) {
            kickoffTeam = playerTeam;
            document.getElementById('coin-result').textContent = 
                t.coinResultWin.replace('{result}', resultText);
        } else {
            kickoffTeam = playerTeam === 1 ? 2 : 1;
            document.getElementById('coin-result').textContent = 
                t.coinResultLose.replace('{result}', resultText);
        }
        
        document.getElementById('coin-result').classList.remove('hidden');
        document.getElementById('continue-game').classList.remove('hidden');
    }, 1000);
}

function startGame() {
    document.getElementById('coin-flip-screen').classList.add('hidden');
    document.getElementById('game-screen').classList.remove('hidden');
    gameState = 'playing';
    
    // Initialize Three.js game
    initializeGame();
}

// Three.js setup
let scene, camera, renderer;

function initializeGame() {
    // Three.js setup
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB);
    
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.getElementById('game-screen').appendChild(renderer.domElement);
    
    // Verlichting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 100, 50);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);
    
    // Create game objects
    createField();
    createGoals();
    createPlayers();
    createBall();
    
    // Position ball for kickoff
    positionForKickoff();
    
    // Camera position
    camera.position.set(0, 60, 40);
    camera.lookAt(0, 0, 0);
    
    // Update texts
    updateTexts();
    
    // Start game loop
    animate();
}

function positionForKickoff() {
    // Reset ball to center
    window.ball.position.set(0, BALL_SIZE, 0);
    window.ball.velocity = { x: 0, y: 0, z: 0 };
    
    // Position players for kickoff
    if (kickoffTeam === 1) {
        // Team 1 kicks off
        window.team1Players[1].position.set(-5, PLAYER_SIZE/2, 0);
        window.team1Players[2].position.set(-10, PLAYER_SIZE/2, 0);
    } else {
        // Team 2 kicks off
        window.team2Players[1].position.set(5, PLAYER_SIZE/2, 0);
        window.team2Players[2].position.set(10, PLAYER_SIZE/2, 0);
    }
}

// Veld maken
function createField() {
    // Gras
    const grassGeometry = new THREE.PlaneGeometry(FIELD_W, FIELD_L);
    const grassMaterial = new THREE.MeshLambertMaterial({ color: 0x228B22 });
    const grass = new THREE.Mesh(grassGeometry, grassMaterial);
    grass.rotation.x = -Math.PI / 2;
    grass.receiveShadow = true;
    scene.add(grass);
    
    // Veldlijnen
    const lineMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
    
    // Buitenlijnen
    const lines = [
        { pos: [0, 0.02, -FIELD_L/2], size: [FIELD_W, 0.2, 0.2] },
        { pos: [0, 0.02, FIELD_L/2], size: [FIELD_W, 0.2, 0.2] },
        { pos: [-FIELD_W/2, 0.02, 0], size: [0.2, 0.2, FIELD_L] },
        { pos: [FIELD_W/2, 0.02, 0], size: [0.2, 0.2, FIELD_L] },
        { pos: [0, 0.02, 0], size: [0.2, 0.2, FIELD_L] }
    ];
    
    lines.forEach(line => {
        const geometry = new THREE.BoxGeometry(...line.size);
        const mesh = new THREE.Mesh(geometry, lineMaterial);
        mesh.position.set(...line.pos);
        scene.add(mesh);
    });
    
    // Middencirkel
    const circleGeometry = new THREE.RingGeometry(9.8, 10.2, 32);
    const circleMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const circle = new THREE.Mesh(circleGeometry, circleMaterial);
    circle.rotation.x = -Math.PI / 2;
    circle.position.y = 0.02;
    scene.add(circle);
}

// Doelen maken
function createGoals() {
    const goalMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });
    
    // Linker doel
    const postGeometry = new THREE.CylinderGeometry(0.1, 0.1, GOAL_H);
    const crossbarGeometry = new THREE.CylinderGeometry(0.1, 0.1, GOAL_W);
    
    // Linker paal
    const leftPost1 = new THREE.Mesh(postGeometry, goalMaterial);
    leftPost1.position.set(-FIELD_W/2, GOAL_H/2, -GOAL_W/2);
    scene.add(leftPost1);
    
    const leftPost2 = new THREE.Mesh(postGeometry, goalMaterial);
    leftPost2.position.set(-FIELD_W/2, GOAL_H/2, GOAL_W/2);
    scene.add(leftPost2);
    
    const leftCrossbar = new THREE.Mesh(crossbarGeometry, goalMaterial);
    leftCrossbar.rotation.z = Math.PI/2;
    leftCrossbar.position.set(-FIELD_W/2, GOAL_H, 0);
    scene.add(leftCrossbar);
    
    // Rechter doel
    const rightPost1 = new THREE.Mesh(postGeometry, goalMaterial);
    rightPost1.position.set(FIELD_W/2, GOAL_H/2, -GOAL_W/2);
    scene.add(rightPost1);
    
    const rightPost2 = new THREE.Mesh(postGeometry, goalMaterial);
    rightPost2.position.set(FIELD_W/2, GOAL_H/2, GOAL_W/2);
    scene.add(rightPost2);
    
    const rightCrossbar = new THREE.Mesh(crossbarGeometry, goalMaterial);
    rightCrossbar.rotation.z = Math.PI/2;
    rightCrossbar.position.set(FIELD_W/2, GOAL_H, 0);
    scene.add(rightCrossbar);
}

// Spelers maken
function createPlayers() {
    const team1Material = new THREE.MeshLambertMaterial({ color: 0xff0000 });
    const team2Material = new THREE.MeshLambertMaterial({ color: 0x0000ff });
    const keeperMaterial = new THREE.MeshLambertMaterial({ color: 0x00ff00 });
    
    const playerGeometry = new THREE.CylinderGeometry(PLAYER_SIZE/2, PLAYER_SIZE/2, PLAYER_SIZE);
    
    // Team 1 (rood)
    const team1Positions = [
        [-50, 0], // Keeper
        [-35, -15], [-35, 15], [-20, -10], [-20, 10]
    ];
    
    window.team1Players = [];
    team1Positions.forEach((pos, i) => {
        const material = i === 0 ? keeperMaterial : team1Material;
        const player = new THREE.Mesh(playerGeometry, material);
        player.position.set(pos[0], PLAYER_SIZE/2, pos[1]);
        player.castShadow = true;
        player.team = 1;
        player.isKeeper = i === 0;
        player.homePosition = { x: pos[0], z: pos[1] };
        scene.add(player);
        window.team1Players.push(player);
        
        // Als rood team is gekozen, maak de eerste veldspeler bestuurbaar
        if (playerTeam === 1 && i === 1) {
            window.controlledPlayer = player;
        }
    });
    
    // Team 2 (blauw)
    const team2Positions = [
        [50, 0], // Keeper
        [35, -15], [35, 15], [20, -10], [20, 10]
    ];
    
    window.team2Players = [];
    team2Positions.forEach((pos, i) => {
        const material = i === 0 ? keeperMaterial : team2Material;
        const player = new THREE.Mesh(playerGeometry, material);
        player.position.set(pos[0], PLAYER_SIZE/2, pos[1]);
        player.castShadow = true;
        player.team = 2;
        player.isKeeper = i === 0;
        player.homePosition = { x: pos[0], z: pos[1] };
        scene.add(player);
        window.team2Players.push(player);
        
        // Als blauw team is gekozen, maak de eerste veldspeler bestuurbaar
        if (playerTeam === 2 && i === 1) {
            window.controlledPlayer = player;
        }
    });
}

// Bal maken
function createBall() {
    const ballGeometry = new THREE.SphereGeometry(BALL_SIZE);
    const ballMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });
    window.ball = new THREE.Mesh(ballGeometry, ballMaterial);
    window.ball.position.set(0, BALL_SIZE, 0);
    window.ball.castShadow = true;
    window.ball.velocity = { x: 0, y: 0, z: 0 };
    scene.add(window.ball);
}

// Input handling
const keys = {};

document.addEventListener('keydown', (event) => {
    keys[event.code] = true;
});

document.addEventListener('keyup', (event) => {
    keys[event.code] = false;
});

// Speler beweging
function updatePlayerMovement() {
    if (!window.controlledPlayer || gameState !== 'playing') return;
    
    const speed = 0.3;
    
    if (keys['ArrowUp'] || keys['KeyW']) {
        window.controlledPlayer.position.z -= speed;
    }
    if (keys['ArrowDown'] || keys['KeyS']) {
        window.controlledPlayer.position.z += speed;
    }
    if (keys['ArrowLeft'] || keys['KeyA']) {
        window.controlledPlayer.position.x -= speed;
    }
    if (keys['ArrowRight'] || keys['KeyD']) {
        window.controlledPlayer.position.x += speed;
    }
    
    // Grenzen
    window.controlledPlayer.position.x = Math.max(-FIELD_W/2 + PLAYER_SIZE/2, 
        Math.min(FIELD_W/2 - PLAYER_SIZE/2, window.controlledPlayer.position.x));
    window.controlledPlayer.position.z = Math.max(-FIELD_L/2 + PLAYER_SIZE/2, 
        Math.min(FIELD_L/2 - PLAYER_SIZE/2, window.controlledPlayer.position.z));
}

// AI voor veldspelers
function updateAI() {
    // Alle spelers behalve de bestuurde speler
    const allPlayers = [...window.team1Players, ...window.team2Players];
    
    allPlayers.forEach(player => {
        // Skip de speler die door de gebruiker wordt bestuurd
        if (player === window.controlledPlayer) return;
        
        // Keeper AI wordt apart afgehandeld
        if (player.isKeeper) return;
        
        const ballDistance = Math.sqrt(
            Math.pow(player.position.x - window.ball.position.x, 2) + 
            Math.pow(player.position.z - window.ball.position.z, 2)
        );
        
        if (ballDistance < 15) {
            // Ga naar de bal
            const dx = window.ball.position.x - player.position.x;
            const dz = window.ball.position.z - player.position.z;
            const distance = Math.sqrt(dx * dx + dz * dz);
            
            if (distance > 0) {
                player.position.x += (dx / distance) * 0.15;
                player.position.z += (dz / distance) * 0.15;
            }
            
            // Als dicht bij de bal, probeer te passen of schieten
            if (ballDistance < PLAYER_SIZE/2 + BALL_SIZE + 0.5) {
                const teammates = allPlayers.filter(p => p.team === player.team && p !== player);
                
                // Zoek naar een teamgenoot om naar te passen
                let bestTeammate = null;
                let bestDistance = Infinity;
                
                teammates.forEach(teammate => {
                    const teammateDistance = Math.sqrt(
                        Math.pow(teammate.position.x - player.position.x, 2) + 
                        Math.pow(teammate.position.z - player.position.z, 2)
                    );
                    
                    if (teammateDistance < bestDistance && teammateDistance > 5) {
                        bestTeammate = teammate;
                        bestDistance = teammateDistance;
                    }
                });
                
                if (bestTeammate) {
                    // Pas naar teamgenoot
                    const dx = bestTeammate.position.x - window.ball.position.x;
                    const dz = bestTeammate.position.z - window.ball.position.z;
                    const distance = Math.sqrt(dx * dx + dz * dz);
                    
                    if (distance > 0) {
                        window.ball.velocity.x = (dx / distance) * 0.5; // Zachter passen
                        window.ball.velocity.z = (dz / distance) * 0.5;
                        window.ball.velocity.y = 0.2;
                    }
                } else {
                    // Schiet naar doel
                    const goalX = player.team === 1 ? FIELD_W/2 : -FIELD_W/2;
                    const dx = goalX - window.ball.position.x;
                    const dz = 0 - window.ball.position.z;
                    const distance = Math.sqrt(dx * dx + dz * dz);
                    
                    if (distance > 0) {
                        window.ball.velocity.x = (dx / distance) * 0.7; // Zachter schieten
                        window.ball.velocity.z = (dz / distance) * 0.7;
                        window.ball.velocity.y = 0.3;
                    }
                }
            }
        } else {
            // Ga naar thuispositie
            const dx = player.homePosition.x - player.position.x;
            const dz = player.homePosition.z - player.position.z;
            const distance = Math.sqrt(dx * dx + dz * dz);
            
            if (distance > 2) {
                player.position.x += (dx / distance) * 0.1;
                player.position.z += (dz / distance) * 0.1;
            }
        }
        
        // Grenzen
        player.position.x = Math.max(-FIELD_W/2 + PLAYER_SIZE/2, 
            Math.min(FIELD_W/2 - PLAYER_SIZE/2, player.position.x));
        player.position.z = Math.max(-FIELD_L/2 + PLAYER_SIZE/2, 
            Math.min(FIELD_L/2 - PLAYER_SIZE/2, player.position.z));
    });
}

// Keeper AI
function updateKeepers() {
    [window.team1Players[0], window.team2Players[0]].forEach(keeper => {
        if (!keeper) return;
        
        const ballDistance = Math.sqrt(
            Math.pow(keeper.position.x - window.ball.position.x, 2) + 
            Math.pow(keeper.position.z - window.ball.position.z, 2)
        );
        
        // Als de bal dichtbij is, ga ernaar toe
        if (ballDistance < 15) {
            const dx = window.ball.position.x - keeper.position.x;
            const dz = window.ball.position.z - keeper.position.z;
            const distance = Math.sqrt(dx * dx + dz * dz);
            
            if (distance > 0) {
                keeper.position.x += (dx / distance) * 0.2;
                keeper.position.z += (dz / distance) * 0.2;
            }
        } else {
            // Ga terug naar doellijn
            const goalX = keeper.team === 1 ? -FIELD_W/2 + 2 : FIELD_W/2 - 2;
            const dx = goalX - keeper.position.x;
            const dz = 0 - keeper.position.z;
            const distance = Math.sqrt(dx * dx + dz * dz);
            
            if (distance > 1) {
                keeper.position.x += (dx / distance) * 0.1;
                keeper.position.z += (dz / distance) * 0.1;
            }
        }
        
        // Beperk keeper tot penalty area
        const penaltyX = keeper.team === 1 ? -FIELD_W/2 + 8 : FIELD_W/2 - 8;
        keeper.position.x = keeper.team === 1 ? 
            Math.max(-FIELD_W/2, Math.min(penaltyX, keeper.position.x)) :
            Math.max(penaltyX, Math.min(FIELD_W/2, keeper.position.x));
        keeper.position.z = Math.max(-8, Math.min(8, keeper.position.z));
    });
}

// Bal physics
function updateBall() {
    if (gameState !== 'playing') return;
    
    // Zwaartekracht
    window.ball.velocity.y -= 0.01;
    
    // Beweging
    window.ball.position.x += window.ball.velocity.x;
    window.ball.position.y += window.ball.velocity.y;
    window.ball.position.z += window.ball.velocity.z;
    
    // Grond contact
    if (window.ball.position.y <= BALL_SIZE) {
        window.ball.position.y = BALL_SIZE;
        window.ball.velocity.y = Math.abs(window.ball.velocity.y) * 0.3; // Minder bounce
        
        // Wrijving
        window.ball.velocity.x *= 0.97; // Meer wrijving
        window.ball.velocity.z *= 0.97;
    }
    
    // Muren
    if (Math.abs(window.ball.position.x) > FIELD_W/2) {
        window.ball.velocity.x *= -0.3; // Minder bounce tegen muren
        window.ball.position.x = Math.sign(window.ball.position.x) * FIELD_W/2;
    }
    if (Math.abs(window.ball.position.z) > FIELD_L/2) {
        window.ball.velocity.z *= -0.3;
        window.ball.position.z = Math.sign(window.ball.position.z) * FIELD_L/2;
    }
    
    // Speler botsingen
    const allPlayers = [...window.team1Players, ...window.team2Players];
    allPlayers.forEach(player => {
        const distance = Math.sqrt(
            Math.pow(player.position.x - window.ball.position.x, 2) + 
            Math.pow(player.position.z - window.ball.position.z, 2)
        );
        
        if (distance < PLAYER_SIZE/2 + BALL_SIZE) {
            const dx = window.ball.position.x - player.position.x;
            const dz = window.ball.position.z - player.position.z;
            const dist = Math.sqrt(dx * dx + dz * dz);
            
            if (dist > 0) {
                window.ball.velocity.x = (dx / dist) * 0.5; // Zachter kaatsen
                window.ball.velocity.z = (dz / dist) * 0.5;
                window.ball.velocity.y = 0.2;
            }
        }
    });
    
    // Doelen controleren
    if (Math.abs(window.ball.position.x) > FIELD_W/2 - 1 && 
        Math.abs(window.ball.position.z) < GOAL_W/2 && 
        window.ball.position.y < GOAL_H) {
        
        if (window.ball.position.x > 0) {
            window.team1Score++;
        } else {
            window.team2Score++;
        }
        
        // Reset bal
        positionForKickoff();
        updateScore();
    }
}

// Score systeem
window.team1Score = 0;
window.team2Score = 0;
window.gameTime = 0;

function updateScore() {
    const scoreElement = document.getElementById('score');
    if (scoreElement) {
        scoreElement.textContent = `${window.team1Score} - ${window.team2Score}`;
    }
}

// Game loop
function animate() {
    if (gameState !== 'playing') return;
    
    requestAnimationFrame(animate);
    
    updatePlayerMovement();
    updateAI();
    updateKeepers();
    updateBall();
    
    window.gameTime += 1/60;
    
    // Update timer
    const timerElement = document.getElementById('timer');
    if (timerElement) {
        const minutes = Math.floor(window.gameTime / 60);
        const seconds = Math.floor(window.gameTime % 60);
        timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // Game over na 5 minuten
    if (window.gameTime > 300) {
        const t = translations[currentLanguage];
        alert(`${t.gameOver}\n${t.finalScore}: ${window.team1Score} - ${window.team2Score}`);
        gameState = 'finished';
    }
    
    renderer.render(scene, camera);
}

// Window resize
window.addEventListener('resize', () => {
    if (camera && renderer) {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }
});